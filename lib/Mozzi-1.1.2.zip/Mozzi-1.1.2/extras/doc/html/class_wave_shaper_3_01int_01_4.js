var class_wave_shaper_3_01int_01_4 =
[
    [ "WaveShaper", "class_wave_shaper_3_01int_01_4.html#a9cc7f4f6a7493172cdc94411ac09275a", null ],
    [ "next", "class_wave_shaper_3_01int_01_4.html#a2bf3bca1848a953c52ae94d5b58199ba", null ]
];